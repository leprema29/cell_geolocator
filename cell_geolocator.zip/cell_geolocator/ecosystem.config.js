module.exports = {
  apps: [
    {
      name: "geolocator-api",
      script: "java",
      args: "-jar /var/www/backend/cell_geolocator-0.0.1-SNAPSHOT.jar",
      cwd: "/var/www/backend",
      env_production: {
        SPRING_PROFILES_ACTIVE: "prod",

        SPRING_DATASOURCE_URL: "jdbc:postgresql://aws-1-eu-west-1.pooler.supabase.com:5432/postgres",
        SPRING_DATASOURCE_USERNAME: "postgres.jptxcxgpoestkqboaffi",
        SPRING_DATASOURCE_PASSWORD: "Emmjf8v8AzjCEo3H",
        SPRING_DATASOURCE_DRIVER_CLASS_NAME: "org.postgresql.Driver",

        OPENCELLID_API_KEY: "pk.e005a9c07a6f6041f5572eb203289627",
        UNWIRED_LABS_API_KEY: "pk.c4a91150dd6aa410f1b83fea1a5b5f6b",
        COMBAIN_API_KEY: "4b141db009d75da7710e",
        LOCATIONIQ_API_KEY: "pk.1a70b6d68cb626ea55f748a111989af9",

        JWT_SECRET: "LFC+CN9XD+5W4z6u8AJj576BIzMTunnWJpDIFcAZvIz4zWJn/GMG778I2dRQdwfck8ra+PgEI+CT9wTrc8ToSg=="
      }
    }
  ]
}
